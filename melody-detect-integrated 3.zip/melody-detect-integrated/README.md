# Melody Detect — Integrated (Sightengine, Hive, SH.Labs)

## Run
Server:
  cd server
  cp config.example.js config.js   # fill provider + creds
  npm install
  npm start  # http://localhost:5000

Client:
  cd client
  npm install
  npm run dev # http://localhost:5173
