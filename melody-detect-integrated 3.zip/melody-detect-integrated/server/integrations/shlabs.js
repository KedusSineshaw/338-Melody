import fs from "fs";
import fetch from "node-fetch";
import FormData from "form-data";

/**
 * SH Labs integration (AI music detection)
 * Expects cfg.shlabs = { apiUrl, apiKey? , authHeader? }
 * - Sends X-API-Key header (from apiKey or authHeader with 'Bearer ' stripped)
 * - Uploads to file.io to get a temporary public audioUrl
 */

async function putTemp(filePath) {
  const form = new FormData();
  form.append("file", fs.createReadStream(filePath));
  const r = await fetch("https://file.io/?expires=1d", {
    method: "POST",
    body: form,
    headers: form.getHeaders(),
  });
  if (!r.ok) throw new Error(`temp upload failed: ${r.status}`);
  const j = await r.json();
  if (!j?.success || !j?.link)
    throw new Error("temp upload: no link returned");
  return j.link;
}

export async function detect(filePath, cfg = {}) {
  const conf = cfg?.shlabs || {};
  if (!conf.apiUrl) throw new Error("SH Labs apiUrl is required");

  // 1️⃣ temp public URL
  const audioUrl = await putTemp(filePath);

  // 2️⃣ call SH Labs
  const headers = { "Content-Type": "application/json" };
  if (conf.authHeader)
    headers["X-API-Key"] = conf.authHeader.replace(/^Bearer\\s+/i, "");
  else if (conf.apiKey) headers["X-API-Key"] = conf.apiKey;

  const res = await fetch(conf.apiUrl, {
    method: "POST",
    headers,
    body: JSON.stringify({ audioUrl }),
  });
  if (!res.ok) throw new Error(`SH Labs API failed: ${res.status}`);
  const json = await res.json();

  // 3️⃣ normalize 0–100 → 0–1
  const pct = json?.result?.probability_ai_generated;
  const aiProb =
    typeof pct === "number" ? Math.min(1, Math.max(0, pct / 100)) : 0.5;

  return { ai_probability: aiProb, raw: json };
}
