// index.js (CommonJS)
const express = require("express");
const fileUpload = require("express-fileupload");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
require("dotenv").config();

let cfg = {};
try {
  cfg = require("./config.js");
} catch (e) {
  cfg = {
    provider: "aiornot",
    aiornot: {
      apiUrl:
        process.env.AIORNOT_API_URL || "https://api.aiornot.com/v1/reports/music",
      apiKey: process.env.AIORNOT_API_KEY
    }
  };
}

const { detect } = require("./integrations/aiornot.js");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(fileUpload());
app.use(express.json());

const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

// POST /api/upload — accepts multipart {file}, runs AI or Not, stores normalized JSON
app.post("/api/upload", (req, res) => {
  if (!req.files || !req.files.file)
    return res.status(400).json({ error: "No file uploaded" });

  const file = req.files.file;
  const filePath = path.join(uploadsDir, file.name);

  file.mv(filePath, async (err) => {
    if (err) return res.status(500).json({ error: "Upload failed" });

    const jobId = Date.now().toString();

    try {
      const result = await detect(filePath, cfg);
      const normalized = {
        status: "done",
        ai_probability: result.ai_probability, // 0..1 probability of being AI
        provider: "aiornot",
        raw: result.raw
      };
      fs.writeFileSync(
        path.join(uploadsDir, `${jobId}.json`),
        JSON.stringify(normalized)
      );
      res.json({ status: "uploaded", job_id: jobId });
    } catch (e) {
      console.error("[AI or Not error]", e.message || e);
      res.status(502).json({ error: "Detection failed", details: e.message });
    }
  });
});

// GET /api/results/:jobId — returns saved result
app.get("/api/results/:jobId", (req, res) => {
  const jobFile = path.join(uploadsDir, `${req.params.jobId}.json`);
  if (!fs.existsSync(jobFile))
    return res.status(404).json({ error: "Result not found" });
  res.json(JSON.parse(fs.readFileSync(jobFile)));
});

app.listen(PORT, () =>
  console.log(`✅ AI or Not server running on http://localhost:${PORT}`)
);
