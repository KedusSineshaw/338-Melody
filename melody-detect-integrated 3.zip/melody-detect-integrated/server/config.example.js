// config.example.js (CommonJS)
module.exports = {
  provider: "aiornot",
  aiornot: {
    apiUrl: "https://api.aiornot.com/v1/reports/music",
    // Choose one:
    //apiKey: "YOUR_AIORNOT_API_KEY",
    // or provide via env: AIORNOT_API_KEY
  }
};
